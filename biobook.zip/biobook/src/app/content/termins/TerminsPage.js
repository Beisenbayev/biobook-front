import * as React from 'react'
import { useEffect, useState } from 'react'
import { useSelector, useDispatch } from 'react-redux'

import { getTerminsSelector } from '../../../store/selectors/terminsSelector'
import { loadTerminsThunk } from '../../../store/actions/terminsActions'

import Grid from '@mui/material/Grid'
import Container from '@mui/material/Container'

import TerminCard from '../../../components/card/TerminCard'
import SearchBar from '../../../components/searchBar/SearchBar'

const TerminsPage = () => {
	const dispath = useDispatch()
	const [searchTerm, setSearchTerm] = useState('')
	const termins = useSelector((store) => getTerminsSelector(store.termins))

	useEffect(() => {
		dispath(loadTerminsThunk())
	}, [])

	const terminItems = termins
		.filter((termin) =>
			termin.title.toLowerCase().includes(searchTerm.toLowerCase())
		)
		.map((termin) => (
			<Grid item key={termin.id} xs={12} sm={12} md={12}>
				<TerminCard title={termin.title} description={termin.description} />
			</Grid>
		))

	return (
		<main>
			<Container sx={{ py: 4 }} maxWidth='md'>
				<SearchBar value={searchTerm} onInput={setSearchTerm} />
			</Container>
			<Container sx={{ py: 4 }} maxWidth='md'>
				<Grid container spacing={4}>
					{terminItems}
				</Grid>
			</Container>
		</main>
	)
}

export default TerminsPage
