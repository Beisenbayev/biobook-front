import * as React from 'react'
import { Link } from 'react-router-dom'

import Grid from '@mui/material/Grid'
import Stack from '@mui/material/Stack'
import Box from '@mui/material/Box'
import Typography from '@mui/material/Typography'
import Container from '@mui/material/Container'
import Button from '@mui/material/Button'

import MediaCard from '../../../components/mediaCard/MediaCard'

const cards = [1, 2, 3, 4, 5, 6, 7, 8, 9]

const Home = () => {
	return (
		<main>
			{/* Hero unit */}
			<Box
				sx={{
					bgcolor: 'background.paper',
					pt: 8,
					pb: 6,
				}}
			>
				<Container maxWidth='md'>
					<Typography
						component='h1'
						variant='h2'
						align='center'
						color='text.primary'
						gutterBottom
					>
						Биоинформа́тика
					</Typography>
					<Typography
						variant='h5'
						align='center'
						color='text.secondary'
						paragraph
					>
						междисциплинарная область, объединяющая общую биологию, молекулярную
						биологию, кибернетику, генетику, химию, компьютерные науки,
						математику и статистику. Биоинформатика главным образом включает в
						себя изучение и разработку компьютерных методов и направлена на
						получение, анализ, хранение, организацию и визуализацию
						биологических данных
					</Typography>
					<Stack
						sx={{ pt: 4 }}
						direction='row'
						spacing={2}
						justifyContent='center'
					>
						<Link to='/termins'>
							<Button variant='contained'>Термины</Button>
						</Link>
						<Button
							href='https://ru.wikipedia.org/wiki/%D0%91%D0%B8%D0%BE%D0%B8%D0%BD%D1%84%D0%BE%D1%80%D0%BC%D0%B0%D1%82%D0%B8%D0%BA%D0%B0'
							variant='outlined'
							target='_blank'
						>
							Wikipedia
						</Button>
					</Stack>
				</Container>
			</Box>
			{/* End hero unit */}

			<Container sx={{ py: 8 }} maxWidth='md'>
				<Grid container spacing={4}>
					{cards.map((card, index) => (
						<Grid item key={index} xs={12} sm={6} md={4}>
							<MediaCard
								title={'Heading'}
								description={
									'This is a media card. You can use this section to describe the content.'
								}
								image={
									'https://atlas.ru/blog/content/images/2022/04/2022-04-14-Genes-and-DNA-2-.png'
								}
							/>
						</Grid>
					))}
				</Grid>
			</Container>
		</main>
	)
}

export default Home
