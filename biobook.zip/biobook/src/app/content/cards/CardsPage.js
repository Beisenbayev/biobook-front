import * as React from 'react'
import { useEffect } from 'react'
import { useSelector, useDispatch } from 'react-redux'

import { getCardsSelector } from '../../../store/selectors/terminsSelector'
import { loadCardsThunk } from '../../../store/actions/terminsActions'

import Grid from '@mui/material/Grid'
import Container from '@mui/material/Container'

import MediaCard from '../../../components/mediaCard/MediaCard'

const CardsPage = () => {
	const dispath = useDispatch()
	const cards = useSelector((store) => getCardsSelector(store.termins))

	useEffect(() => {
		dispath(loadCardsThunk())
	}, [])

	const cardItems = cards.map((card, index) => (
		<Grid item key={index} xs={12} sm={6} md={4}>
			<MediaCard
				title={card.title}
				description={card.description}
				image={card.image}
			/>
		</Grid>
	))

	return (
		<main>
			<Container sx={{ py: 8 }} maxWidth='md'>
				<Grid container spacing={4}>
					{cardItems}
				</Grid>
			</Container>
		</main>
	)
}

export default CardsPage
