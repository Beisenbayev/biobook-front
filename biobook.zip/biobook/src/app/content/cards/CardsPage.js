import * as React from 'react'
import { Link } from 'react-router-dom'

import Grid from '@mui/material/Grid'
import Container from '@mui/material/Container'

import MediaCard from '../../../components/mediaCard/MediaCard'

const cards = [1, 2, 3, 4, 5, 6, 7, 8, 9]

const CardsPage = () => {
	return (
		<main>
			<Container sx={{ py: 8 }} maxWidth='md'>
				<Grid container spacing={4}>
					{cards.map((card, index) => (
						<Grid item key={index} xs={12} sm={6} md={4}>
							<MediaCard
								title={'Heading'}
								description={
									'This is a media card. You can use this section to describe the content.'
								}
								image={
									'https://atlas.ru/blog/content/images/2022/04/2022-04-14-Genes-and-DNA-2-.png'
								}
							/>
						</Grid>
					))}
				</Grid>
			</Container>
		</main>
	)
}

export default CardsPage
