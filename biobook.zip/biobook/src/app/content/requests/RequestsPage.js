import * as React from 'react'
import { useEffect, useState } from 'react'
import { useSelector, useDispatch } from 'react-redux'

import {
	getRequestsSelector,
	getIsFetchingSelector,
} from '../../../store/selectors/terminsSelector'
import {
	loadRequestsThunk,
	createRequestThunk,
	deleteRequestThunk,
} from '../../../store/actions/terminsActions'

import Grid from '@mui/material/Grid'
import Container from '@mui/material/Container'
import Box from '@mui/material/Box'
import Button from '@mui/material/Button'
import TextField from '@mui/material/TextField'

import TerminCard from '../../../components/card/TerminCard'

const RequestsPage = () => {
	const [title, setTitle] = useState('')
	const [description, setDescription] = useState('')
	const fieldSetters = {
		title: setTitle,
		description: setDescription,
	}

	const dispath = useDispatch()
	const requests = useSelector((store) => getRequestsSelector(store.termins))
	const isSubmitting = useSelector((store) => getIsFetchingSelector(store.auth))

	useEffect(() => {
		dispath(loadRequestsThunk())
	}, [])

	const handleCreateRequest = (event) => {
		event.preventDefault()

		if (!title || !description) return

		dispath(createRequestThunk({ title, description }))

		for (let field in fieldSetters) {
			fieldSetters[field]('')
		}
	}

	const handleDeleteRequest = (id) => {
		dispath(deleteRequestThunk(id))
	}

	const handleSetFieldValue = (id, event) => {
		fieldSetters[id](event.target.value)
	}

	const requestItems = requests.map((termin) => (
		<Grid item key={termin.id} xs={12} sm={12} md={12}>
			<TerminCard title={termin.title} description={termin.description} />
		</Grid>
	))

	return (
		<main>
			<Container sx={{ py: 4 }} maxWidth='md'>
				<Box
					component='form'
					// noValidate
					onSubmit={handleCreateRequest}
					sx={{ mt: 1 }}
				>
					<TextField
						margin='normal'
						required
						fullWidth
						id='title'
						label='Title: '
						name='title'
						autoComplete='title'
						autoFocus
						value={title}
						onChange={(e) => handleSetFieldValue('title', e)}
					/>
					<TextField
						margin='normal'
						required
						fullWidth
						name='description'
						label='Description: '
						id='description'
						autoComplete='description'
						value={description}
						onChange={(e) => handleSetFieldValue('description', e)}
					/>
					<Button
						type='submit'
						fullWidth
						variant='contained'
						sx={{ mt: 3, mb: 2 }}
						disabled={isSubmitting}
					>
						Create request
					</Button>
				</Box>
			</Container>
			<Container sx={{ py: 4 }} maxWidth='md'>
				<Grid container spacing={4}>
					{requestItems}
				</Grid>
			</Container>
		</main>
	)
}

export default RequestsPage
