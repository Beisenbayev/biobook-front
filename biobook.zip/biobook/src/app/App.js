import * as React from 'react'
import { useEffect } from 'react'
import { useSelector, useDispatch } from 'react-redux'
import { Route, Routes, Navigate, useNavigate } from 'react-router-dom'

import { getIsAuthSelector } from '../store/selectors/authSelector'
import { getInitializedSelector } from '../store/selectors/appSelector'
import { initAppThunk } from '../store/actions/appActions'

import CssBaseline from '@mui/material/CssBaseline'
import { createTheme, ThemeProvider } from '@mui/material/styles'

import Header from '../components/header/Header'
import Footer from '../components/footer/Footer'
import HomePage from './content/home/HomePage'
import CardsPage from './content/cards/CardsPage'
import TerminsPage from './content/termins/TerminsPage'
import RequestsPage from './content/requests/RequestsPage'

const theme = createTheme()

const App = () => {
	const dispath = useDispatch()
	const navigate = useNavigate()
	const isAuth = useSelector((store) => getIsAuthSelector(store.auth))
	const isInit = useSelector((store) => getInitializedSelector(store.app))

	useEffect(() => {
		if (!isAuth) navigate('/login')
		else dispath(initAppThunk())
	}, [isAuth])

	if (!isInit) return <div></div>

	return (
		<ThemeProvider theme={theme}>
			<CssBaseline />
			<Header />

			<Routes>
				<Route path='/' element={<HomePage />} />
				<Route path='termins' element={<TerminsPage />} />
				<Route path='cards' element={<CardsPage />} />
				<Route path='requests' element={<RequestsPage />} />
				<Route path='*' element={<Navigate to='/error' />} />
			</Routes>

			<Footer />
		</ThemeProvider>
	)
}

export default App
