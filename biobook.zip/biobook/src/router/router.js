import React from 'react'
import { useRoutes } from 'react-router-dom'

import App from '../app/App'
import SignUp from '../app/auth/signUp/SignUp'
import SignIn from '../app/auth/signIn/SignIn'
import ErrorPage from '../app/error/errorPage'

const routeConfig = [
	{ path: '/*', element: <App /> },
	{ path: '/register', element: <SignUp /> },
	{ path: '/login', element: <SignIn /> },
	{ path: '/error', element: <ErrorPage /> },
]

const Router = (props) => {
	const routes = useRoutes(routeConfig)

	return <>{routes}</>
}

export default Router
