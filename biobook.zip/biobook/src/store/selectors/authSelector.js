export const getIsAuthSelector = (state) => {
	return state.isAuth
}

export const getIsSubmittingSelector = (state) => {
	return state.isFetching
}
