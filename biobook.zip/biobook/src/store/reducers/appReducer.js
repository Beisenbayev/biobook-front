import {
	START_INITIALIZATION,
	CONFIRM_INITIALIZATION,
} from '../actions/appActions'

const initState = {
	initialized: false,
}

const authReducer = (state = initState, action) => {
	switch (action.type) {
		case START_INITIALIZATION: {
			return { ...state, initialized: false }
		}
		case CONFIRM_INITIALIZATION: {
			return { ...state, initialized: true }
		}
		default:
			return state
	}
}

export default authReducer
