import {
	TOGGLE_FETCHING,
	SET_TERMINS_DATA,
	SET_CARDS_DATA,
	SET_REQUESTS_DATA,
} from '../actions/terminsActions'

const initState = {
	isFetching: false,
	cards: [],
	termins: [],
	requests: [],
}

const terminsReducer = (state = initState, action) => {
	switch (action.type) {
		case TOGGLE_FETCHING:
			return { ...state, isFetching: action.payload }
		case SET_TERMINS_DATA:
			return { ...state, termins: action.payload }
		case SET_CARDS_DATA:
			return { ...state, cards: action.payload }
		case SET_REQUESTS_DATA:
			return { ...state, requests: action.payload }
		default:
			return state
	}
}

export default terminsReducer
