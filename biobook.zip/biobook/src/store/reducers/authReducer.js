import {
	TOGGLE_FETCHING,
	SET_TOKEN,
	CLEAR_AUTH_DATA,
	SET_USER_DATA,
} from '../actions/authActions'

const initState = {
	token: null,
	isFetching: false,
	isAuth: false,
	user: null,
}

const authReducer = (state = initState, action) => {
	switch (action.type) {
		case TOGGLE_FETCHING: {
			return { ...state, isFetching: action.payload }
		}
		case SET_TOKEN: {
			return { ...state, token: action.payload, isAuth: true }
		}
		case CLEAR_AUTH_DATA: {
			return { ...state, token: null, isAuth: false, user: null }
		}
		case SET_USER_DATA: {
			return { ...state, user: action.payload }
		}
		default:
			return state
	}
}

export default authReducer
