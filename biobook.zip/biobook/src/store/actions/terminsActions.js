import terminsService from '../../services/terminsService'
import cardsService from '../../services/cardsService'

//ACTIONS
export const TOGGLE_FETCHING = 'TOGGLE_FETCHING'
export const SET_TERMINS_DATA = 'SET_TERMINS_DATA'
export const SET_CARDS_DATA = 'SET_CARDS_DATA'

//ACTION CREATORS
const toggleFetchingAC = (isFetching) => {
	return {
		type: TOGGLE_FETCHING,
		payload: isFetching,
	}
}

const setTerminsDataAC = (data) => {
	return {
		type: SET_TERMINS_DATA,
		payload: data,
	}
}

const setCardsDataAC = (data) => {
	return {
		type: SET_CARDS_DATA,
		payload: data,
	}
}

//THUNKS
export const loadTerminsThunk = () => {
	return async (dispatch) => {
		dispatch(toggleFetchingAC(true))
		try {
			const response = await terminsService.getTermins()
			dispatch(setTerminsDataAC(response.result))
		} catch (error) {
			console.log(error.response.status)
		} finally {
			dispatch(toggleFetchingAC(false))
		}
	}
}

export const loadCardsThunk = () => {
	return async (dispatch) => {
		dispatch(toggleFetchingAC(true))
		try {
			const response = await cardsService.getCards()
			dispatch(setCardsDataAC(response.result))
		} catch (error) {
			console.log(error.response.status)
		} finally {
			dispatch(toggleFetchingAC(false))
		}
	}
}
