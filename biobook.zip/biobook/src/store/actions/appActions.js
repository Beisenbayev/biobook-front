import { loadCurrentUserThunk } from './authActions'

//ACTIONS
export const START_INITIALIZATION = 'START_INITIALIZATION'
export const CONFIRM_INITIALIZATION = 'CONFIRM_INITIALIZATION'

//ACTION CREATORS
const startInitAC = () => {
	return {
		type: START_INITIALIZATION,
	}
}

const confirmInitAC = () => {
	return {
		type: CONFIRM_INITIALIZATION,
	}
}

//THUNKS
export const initAppThunk = () => {
	return async (dispath) => {
		dispath(startInitAC())
		try {
			//await dispath(loadCurrentUserThunk())
			dispath(confirmInitAC())
		} catch (error) {
			console.log(error.response)
		}
	}
}
