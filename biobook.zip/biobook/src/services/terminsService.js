import { authInstance, instance } from '../api/config'

const endpoints = {
	termin: '/termins',
	terminById: (terminId) => `/termins/${terminId}`,
}

const terminsService = {
	getTermins: async () => {
		const response = await authInstance.get(endpoints.termin)
		return response.data
	},
	getTerminById: async (terminId) => {
		const response = await authInstance.get(endpoints.terminById(terminId))
		return response.data
	},
	createTermin: async (data) => {
		const response = await authInstance.post(endpoints.termin, data)
		return response.data
	},
	deleteTermin: async (terminId) => {
		const response = await authInstance.delete(endpoints.terminById(terminId))
		return response.data
	},
}

export default terminsService
