import { authInstance, instance } from '../api/config'

const endpoints = {
	request: 'requests',
	requestById: (requestId) => `requests/${requestId}`,
}

const requestsService = {
	getRequests: async () => {
		const response = await authInstance.get(endpoints.request)
		return response.data
	},
	getRequestById: async (requestId) => {
		const response = await authInstance.get(endpoints.requestById(requestId))
		return response.data
	},
	createRequest: async (data) => {
		const response = await authInstance.post(endpoints.request, data)
		return response.data
	},
	deleteRequest: async (requestId) => {
		const response = await authInstance.delete(endpoints.requestById(requestId))
		return response.data
	},
}

export default requestsService
