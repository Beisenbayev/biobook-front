import { authInstance, instance } from '../api/config'

const endpoints = {
	cards: '/cards',
	cardById: (cardId) => `/cards/${cardId}`,
}

const cardsService = {
	getCards: async () => {
		const response = await authInstance.get(endpoints.cards)
		return response.data
	},
	getCardById: async (cardId) => {
		const response = await authInstance.get(endpoints.cardById(cardId))
		return response.data
	},
}

export default cardsService
