import { authInstance, instance } from '../api/config'

const endpoints = {
	login: 'auth/login',
	currentUser: 'auth/me',
}

const authService = {
	login: async (email, password) => {
		const response = await instance.post(endpoints.login, {
			email,
			password,
		})

		if (response.data && response.data.success) {
			localStorage.setItem('token', response.data.result.token)
		}

		return response.data.result
	},
	getCurrentUserData: async () => {
		const response = await authInstance.get(endpoints.currentUser)
		return response.data
	},
}

export default authService
