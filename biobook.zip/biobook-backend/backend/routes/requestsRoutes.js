const express = require('express')
const { protect } = require('../middlewares/authMiddleware')
const router = express.Router()
const {
	getRequests,
	getRequestById,
	createRequest,
	updateRequest,
	deleteRequest,
} = require('../controllers/requestControllers')

router.get('/', protect, getRequests)
router.post('/', protect, createRequest)
router.delete('/:id', protect, deleteRequest)

module.exports = router
