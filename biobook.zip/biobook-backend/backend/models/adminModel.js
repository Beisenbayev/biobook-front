const mongoose = require("mongoose");
const { schemaOptions } = require('../utils/configs/modelConfigs');
const {
   passwordValidator
} = require('../utils/validators/passwordValidator');
const {
   generateEncryptedPassword,
   comparePasswords
} = require('../utils/helpers/encryptedPassword')

const adminSchema = mongoose.Schema({
   email: {
      type: String,
      required: true,
      unique: true,
      immutable: true
   },
   password: {
      type: String,
      required: true,
      validate: [passwordValidator, 'Invalid password']
   },
   created_at: {
      type: Date,
      default: Date.now,
      immutable: true
   }
}, schemaOptions);


adminSchema.pre('save', async function save(next) {
   if (!this.isModified('password')) return next();
   try {
      this.password = await generateEncryptedPassword(this.password);
      return next();
   } catch (err) {
      return next(err);
   }
});

adminSchema.methods.validatePassword = async function (data) {
   const isMatch = await comparePasswords(data, this.password);
   return isMatch;
};


module.exports = mongoose.model('Admin', adminSchema);