const mongoose = require('mongoose')
const { schemaOptions } = require('../utils/configs/modelConfigs')
const { passwordValidator } = require('../utils/validators/passwordValidator')
const {
	generateEncryptedPassword,
	comparePasswords,
} = require('../utils/helpers/encryptedPassword')

const userSchema = mongoose.Schema(
	{
		email: {
			type: String,
			required: [true, 'is required'],
			unique: true,
		},
		password: {
			type: String,
			required: [true, 'is required'],
			validate: [passwordValidator, 'Invalid password'],
		},
		hash_password: {
			type: String,
		},
		first_name: {
			type: String,
			required: [true, 'is required'],
		},
		last_name: {
			type: String,
			required: [true, 'is required'],
		},
		created_at: {
			type: Date,
			default: Date.now,
		},
		requests: {
			type: [mongoose.Schema.Types.ObjectId],
			ref: 'Request',
			default: [],
		},
	},
	schemaOptions
)

userSchema.virtual('full_name').get(function () {
	return `${this.first_name} ${this.last_name}`
})

userSchema.pre('save', async function save(next) {
	if (!this.isModified('password')) return next()
	try {
		this.hash_password = await generateEncryptedPassword(this.password)
		return next()
	} catch (err) {
		return next(err)
	}
})

userSchema.methods.validatePassword = async function (data) {
	const isMatch = await comparePasswords(data, this.hash_password)
	return isMatch
}

module.exports = mongoose.model('User', userSchema)
