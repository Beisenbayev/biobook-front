const express = require('express')
const dotenv = require('dotenv').config()
const connectDB = require('./config/db')
const { errorHandler } = require('./middlewares/errorMiddleware')
const { corsAccept } = require('./middlewares/corsMiddleware')

//database connection
connectDB()

//server init
const app = express()
const port = process.env.SERVER_PORT || 5000

//admin panel init
app.use('/admin', require('./admin/adminRouter'))

//default settings
app.use(express.json())
app.use(express.urlencoded({ extended: false }))

//cors accept
app.use(corsAccept)

//api routes
app.use('/api/auth/', require('./routes/accountRoutes'))
app.use('/api/termins/', require('./routes/terminRoutes'))
app.use('/api/cards/', require('./routes/cardRoutes'))
app.use('/api/requests/', require('./routes/requestsRoutes'))

//error handler
app.use(errorHandler)

app.listen(port, () => {
	console.log(`Server was started on port ${port}`)
})
