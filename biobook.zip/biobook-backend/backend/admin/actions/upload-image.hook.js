const AdminJS = require('adminjs');
const path = require('path');
const fs = require('fs');

const afterUploadImage = async (response, request, context) => {
   const { record, uploadImage } = context;

   if (record.isValid() && uploadImage) {
      const filePath = path.join('uploads', record.id().toString(), uploadImage.name);
      await fs.promises.mkdir(path.dirname(filePath), { recursive: true });
      await fs.promises.rename(uploadImage.path, filePath);

      await record.update({ poster_image: `/${filePath}` })
   }

   return response;
}

const beforeUploadImage = async (request, context) => {
   if (request.method === 'post') {
      const { poster_image, ...params } = request.payload;

      context.uploadImage = poster_image;

      return { ...request, payload: params };
   }

   return request;
}


module.exports = {
   beforeUploadImage,
   afterUploadImage
}