const bcrypt = require('bcryptjs')
const AdminJS = require('adminjs')
const AdminJSExpress = require('@adminjs/express')
const AdminJSMongoose = require('@adminjs/mongoose')
const Admin = require('../models/adminModel')

AdminJS.registerAdapter(AdminJSMongoose)

const adminConfig = require('./adminConfig')

//const adminRouter = AdminJSExpress.buildRouter(adminConfig)

const adminRouter = AdminJSExpress.buildAuthenticatedRouter(adminConfig, {
	authenticate: async (email, password) => {
		const admin = await Admin.findOne({ email })
		if (admin && (await admin.validatePassword(password))) {
			return admin
		}
		return null
	},
	cookieName: process.env.ADMIN_COOKIE_NAME || 'admin',
	cookiePassword:
		process.env.ADMIN_COOKIE_PASSWORD ||
		'some-secret-password-used-to-secure-cookie',
})

module.exports = adminRouter
