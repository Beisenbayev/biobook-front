import * as React from 'react'
import { Route, Routes, Navigate } from 'react-router-dom'

import CssBaseline from '@mui/material/CssBaseline'
import { createTheme, ThemeProvider } from '@mui/material/styles'

import Header from '../components/header/Header'
import Footer from '../components/footer/Footer'
import HomePage from './content/home/HomePage'
import CardsPage from './content/cards/CardsPage'
import TerminsPage from './content/termins/TerminsPage'

const theme = createTheme()

const App = () => {
	return (
		<ThemeProvider theme={theme}>
			<CssBaseline />
			<Header />

			<Routes>
				<Route path='/' element={<HomePage />} />
				<Route path='termins' element={<TerminsPage />} />
				<Route path='cards' element={<CardsPage />} />
				<Route path='requests' element={<div>settings</div>} />
				<Route path='*' element={<Navigate to='/error' />} />
			</Routes>

			<Footer />
		</ThemeProvider>
	)
}

export default App
