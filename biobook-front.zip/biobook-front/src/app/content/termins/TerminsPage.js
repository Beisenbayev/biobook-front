import * as React from 'react'
import { Link } from 'react-router-dom'

import Grid from '@mui/material/Grid'
import Container from '@mui/material/Container'

import TerminCard from '../../../components/card/TerminCard'

const cards = [1, 2, 3, 4, 5, 6, 7, 8, 9]

const TerminsPage = () => {
	return (
		<main>
			<Container sx={{ py: 8 }} maxWidth='md'>
				<Grid container spacing={4}>
					{cards.map((card, index) => (
						<Grid item key={index} xs={12} sm={12} md={12}>
							<TerminCard
								title={'Heading'}
								description={
									'This is a media card. You can use this section to describe the content.'
								}
							/>
						</Grid>
					))}
				</Grid>
			</Container>
		</main>
	)
}

export default TerminsPage
