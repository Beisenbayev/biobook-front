import * as React from 'react'
import { Link } from 'react-router-dom'

import Typography from '@mui/material/Typography'
import Button from '@mui/material/Button'
import Card from '@mui/material/Card'
import CardActions from '@mui/material/CardActions'
import CardContent from '@mui/material/CardContent'
import CardMedia from '@mui/material/CardMedia'

const MediaCard = (props) => {
	return (
		<Card
			variant='outlined'
			sx={{
				height: '100%',
				display: 'flex',
				flexDirection: 'column',
			}}
		>
			<CardMedia
				component='img'
				height='150'
				image={props.image}
				alt='random'
			/>
			<CardContent sx={{ flexGrow: 1 }}>
				<Typography gutterBottom variant='h5' component='h2'>
					{props.title}
				</Typography>
				<Typography>{props.description}</Typography>
			</CardContent>
			<CardActions>
				<Link to={`/1`}>
					<Button size='small'>View</Button>
				</Link>
			</CardActions>
		</Card>
	)
}

export default MediaCard
