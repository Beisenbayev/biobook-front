export const getInitializedSelector = (state) => {
	return state.initialized
}
