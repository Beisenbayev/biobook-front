export const getIsFetchingSelector = (state) => {
	return state.isFetching
}

export const getTerminsSelector = (state) => {
	return state.termins
}

export const getCardsSelector = (state) => {
	return state.cards
}

export const getRequestsSelector = (state) => {
	return state.requests
}
