export const getIsAuthSelector = (state) => {
	return state.isAuth
}

export const getIsFetchingSelector = (state) => {
	return state.isFetching
}
