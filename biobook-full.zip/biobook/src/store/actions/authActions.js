import authService from '../../services/authService'

//ACTION CONSTS
export const TOGGLE_FETCHING = 'TOGGLE_FETCHING'
export const SET_TOKEN = 'SET_TOKEN'
export const CLEAR_AUTH_DATA = 'CLEAR_AUTH_DATA'
export const SET_USER_DATA = 'SET_USER_DATA'

//ACTION CREATORS
const toggleFetchingAC = (isFetching) => {
	return {
		type: TOGGLE_FETCHING,
		payload: isFetching,
	}
}

const setTokenAC = (token) => {
	return {
		type: SET_TOKEN,
		payload: token,
	}
}

const setUserDataAC = (userData) => {
	return {
		type: SET_USER_DATA,
		payload: userData,
	}
}

const clearAuthDataAC = () => {
	return {
		type: CLEAR_AUTH_DATA,
		payload: null,
	}
}

//THUNKS
export const registerThunk = (data) => {
	return async (dispatch) => {
		try {
			const response = await authService.register(data)
			localStorage.setItem('token', response.token)
			dispatch(setTokenAC(response.token))
			dispatch(setUserDataAC(response.user))
		} catch (error) {
			console.log(error.response)
		}
	}
}

export const loginThunk = (email, password) => {
	return async (dispatch) => {
		try {
			const response = await authService.login(email, password)
			localStorage.setItem('token', response.token)
			dispatch(setTokenAC(response.token))
		} catch (error) {
			console.log(error.response)
		}
	}
}

export const logoutThunk = () => {
	localStorage.removeItem('token')
	return async (dispatch) => {
		dispatch(toggleFetchingAC(false))
		dispatch(clearAuthDataAC())
	}
}

export const loadCurrentUserThunk = () => {
	return async (dispatch) => {
		try {
			const response = await authService.getCurrentUserData()
			dispatch(setUserDataAC(response.result))
		} catch (error) {
			console.log(error.response)
		}
	}
}
