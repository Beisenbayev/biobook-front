import * as React from 'react'
import { useEffect, useState } from 'react'
import { useSelector, useDispatch } from 'react-redux'

import { getRequestsSelector } from '../../../store/selectors/terminsSelector'
import {
	loadRequestsThunk,
	createRequestThunk,
	deleteRequestThunk,
} from '../../../store/actions/terminsActions'

import Grid from '@mui/material/Grid'
import Container from '@mui/material/Container'
import Box from '@mui/material/Box'
import Button from '@mui/material/Button'
import CssBaseline from '@mui/material/CssBaseline'
import TextField from '@mui/material/TextField'

import TerminCard from '../../../components/card/TerminCard'

const RequestsPage = () => {
	const dispath = useDispatch()
	const requests = useSelector((store) => getRequestsSelector(store.termins))

	useEffect(() => {
		dispath(loadRequestsThunk())
	}, [])

	const handleCreateRequest = (event) => {
		event.preventDefault()
		const data = new FormData(event.currentTarget)

		const title = data.get('title')
		const description = data.get('description')

		if (!title || !description) return

		dispath(createRequestThunk({ title, description }))
	}

	const handleDeleteRequest = (id) => {
		dispath(deleteRequestThunk(id))
	}

	const requestItems = requests.map((termin) => (
		<Grid item key={termin.id} xs={12} sm={12} md={12}>
			<TerminCard title={termin.title} description={termin.description} />
		</Grid>
	))

	return (
		<main>
			<Container sx={{ py: 4 }} maxWidth='md'>
				<Box
					component='form'
					// noValidate
					onSubmit={handleCreateRequest}
					sx={{ mt: 1 }}
				>
					<TextField
						margin='normal'
						required
						fullWidth
						id='title'
						label='Title: '
						name='title'
						autoComplete='title'
						autoFocus
					/>
					<TextField
						margin='normal'
						required
						fullWidth
						name='description'
						label='Description: '
						id='description'
						autoComplete='description'
					/>
					<Button
						type='submit'
						fullWidth
						variant='contained'
						sx={{ mt: 3, mb: 2 }}
					>
						Create request
					</Button>
				</Box>
			</Container>
			<Container sx={{ py: 4 }} maxWidth='md'>
				<Grid container spacing={4}>
					{requestItems}
				</Grid>
			</Container>
		</main>
	)
}

export default RequestsPage
