import axios from 'axios'

const apiConfig = {
	baseUrl: 'http://localhost:5001/api/',
}

export const instance = axios.create({
	baseURL: apiConfig.baseUrl,
})

export const authInstance = axios.create({
	baseURL: apiConfig.baseUrl,
	headers: {
		authorization: `Bearer ${localStorage.getItem('token') || ''}`,
	},
})
