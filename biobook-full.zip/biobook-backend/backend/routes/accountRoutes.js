const expess = require('express')
const { protect } = require('../middlewares/authMiddleware')
const router = expess.Router()
const {
	register,
	login,
	getCurrentUser,
} = require('../controllers/accountControllers')

router.post('/register', register)
router.post('/login', login)
router.get('/me', protect, getCurrentUser)

module.exports = router
