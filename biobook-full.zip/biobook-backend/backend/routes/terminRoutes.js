const express = require('express')
const router = express.Router()
const {
	getTermins,
	getTerminById,
	createTermin,
	updateTermin,
	deleteTermin,
} = require('../controllers/terminControllers')

router.get('/', getTermins)
router.get('/:id', getTerminById)
router.post('/', createTermin)
router.put('/:id', updateTermin)
router.delete('/:id', deleteTermin)

module.exports = router
