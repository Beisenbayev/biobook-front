const express = require('express')
const router = express.Router()
const { getCards } = require('../controllers/cardControllers')

router.get('/', getCards)

module.exports = router
