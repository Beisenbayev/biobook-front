const asyncHandler = require('express-async-handler')
const Card = require('../models/cardModel')

// @desc    GET CARDS
// @route   GET /api/card
// @access  Private
const getCards = asyncHandler(async (req, res) => {
	const cards = await Card.find()
	res.status(200).json({
		result: cards,
		status_code: 200,
	})
})

module.exports = {
	getCards,
}
