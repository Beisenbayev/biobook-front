const jwt = require('jsonwebtoken')
const dotenv = require('dotenv').config()
const bcrypt = require('bcryptjs')
const asyncHandler = require('express-async-handler')
const User = require('../models/userModel')

//@desc     REGISTER
//@route    POST /api/account/register
//@access   Public
const register = asyncHandler(async (req, res) => {
	const { email } = req.body
	const user = await User.findOne({ email })

	if (user) {
		res.status(400)
		throw new Error('This email is already taken')
	}

	const newUser = await User.create({
		...req.body,
	})

	res.status(200).json({
		result: {
			user: newUser,
			token: generateToken(newUser.id),
		},
		status_code: 200,
	})
})

//@desc     LOGIN
//@route    POST /api/account/login
//@access   Public
const login = asyncHandler(async (req, res) => {
	const { email, password } = req.body
	const student = await User.findOne({ email })

	if (student && (await student.validatePassword(password))) {
		res.status(200).json({
			result: {
				token: generateToken(student.id),
			},
			success: true,
		})
	} else {
		res.status(400)
		throw new Error('Invalid user data')
	}
})

//@desc     GET CURRENT USER DATA
//@route    GET /api/account/me
//@access   Private
const getCurrentUser = asyncHandler(async (req, res) => {
	const student = await User.findById(req.user.id)
	if (!student) {
		res.status(401)
		throw new Error('Invalid token')
	}

	res.status(200).send({
		result: student,
		success: true,
	})
})

//jwt token generator
const generateToken = (id) => {
	return jwt.sign({ id }, process.env.JWT_TOKEN_SECRET, { expiresIn: '30d' })
}

module.exports = {
	register,
	login,
	getCurrentUser,
}
