const asyncHandler = require('express-async-handler')
const Termin = require('../models/terminModel')

// @desc    GET TERMINS
// @route   GET /api/termin
// @access  Private
const getTermins = asyncHandler(async (req, res) => {
	const termins = await Termin.find()
	res.status(200).json({
		result: termins,
		status_code: 200,
	})
})

// @desc    GET TERMIN BY ID
// @route   GET /api/termin/:id
// @access  Private
const getTerminById = asyncHandler(async (req, res) => {
	const termin = await Termin.findById(req.params.id)

	if (!termin) {
		res.status(400)
		throw new Error('Termin not found')
	}

	res.status(200).json({
		result: termin,
		status_code: 200,
	})
})

// @desc    CREATE NEW TERMIN
// @route   POST /api/termin/
// @access  Private
const createTermin = asyncHandler(async (req, res) => {
	const termin = await Termin.create({
		...req.body,
	})

	res.status(200).json({
		result: termin,
		status_code: 200,
	})
})

// @desc    UPDATE TERMIN
// @route   PUT /api/termin/:id
// @access  Private
const updateTermin = asyncHandler(async (req, res) => {
	const termin = await Termin.findById(req.params.id)

	if (!termin) {
		res.status(400)
		throw new Error('termin not found')
	}

	const updatedTermin = await Termin.findByIdAndUpdate(
		req.params.id,
		req.body,
		{
			new: true,
		}
	)
	res.status(200).json({
		result: updatedTermin,
		status_code: 200,
	})
})

// @desc    DELETE TERMIN
// @route   DELETE /api/termin/:id
// @access  Private
const deleteTermin = asyncHandler(async (req, res) => {
	const termin = await Termin.findById(req.params.id)

	if (!termin) {
		res.status(400)
		throw new Error('termin not found')
	}

	await termin.remove()
	res.status(200).json({
		result: { id: req.params.id },
		status_code: 200,
	})
})

module.exports = {
	getTermins,
	getTerminById,
	createTermin,
	updateTermin,
	deleteTermin,
}
