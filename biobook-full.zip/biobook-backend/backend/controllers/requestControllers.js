const asyncHandler = require('express-async-handler')
const Request = require('../models/requestModel')
const User = require('../models/userModel')

// @desc    GET requests
// @route   GET /api/requests
// @access  Private
const getRequests = asyncHandler(async (req, res) => {
	const user = await User.findById(req.user.id)
	if (!user) {
		res.status(401)
		throw new Error('Invalid token')
	}

	const requests = []
	for (let id of user.requests) {
		const request = await Request.findById(id)
		if (request) {
			requests.push(request)
		}
	}

	res.status(200).send({
		result: requests,
		success: true,
	})
})

// @desc    GET TERMIN BY ID
// @route   GET /api/termin/:id
// @access  Private
const getRequestById = asyncHandler(async (req, res) => {
	const request = await Request.findById(req.params.id)

	if (!request) {
		res.status(400)
		throw new Error('Request not found')
	}

	res.status(200).json({
		result: request,
		status_code: 200,
	})
})

// @desc    CREATE NEW TERMIN
// @route   POST /api/termin/
// @access  Private
const createRequest = asyncHandler(async (req, res) => {
	const user = await User.findById(req.user.id)
	if (!user) {
		res.status(401)
		throw new Error('Invalid token')
	}

	const request = await Request.create({
		...req.body,
	})

	user.requests.push(request.id)

	res.status(200).json({
		result: request,
		status_code: 200,
	})
})

// @desc    UPDATE TERMIN
// @route   PUT /api/termin/:id
// @access  Private
const updateRequest = asyncHandler(async (req, res) => {
	const request = await Request.findById(req.params.id)

	if (!request) {
		res.status(400)
		throw new Error('request not found')
	}

	const updatedRequest = await Request.findByIdAndUpdate(
		req.params.id,
		req.body,
		{
			new: true,
		}
	)
	res.status(200).json({
		result: updatedRequest,
		status_code: 200,
	})
})

// @desc    DELETE TERMIN
// @route   DELETE /api/termin/:id
// @access  Private
const deleteRequest = asyncHandler(async (req, res) => {
	const user = await User.findById(req.user.id)
	if (!user) {
		res.status(401)
		throw new Error('Invalid token')
	}

	const request = await Request.findById(req.params.id)
	if (!request) {
		res.status(400)
		throw new Error('request not found')
	}

	requests = user.requests.filter((item) => item != request.id)
	user.requests = requests

	await request.remove()
	res.status(200).json({
		result: { id: req.params.id },
		status_code: 200,
	})
})

module.exports = {
	getRequests,
	getRequestById,
	createRequest,
	updateRequest,
	deleteRequest,
}
