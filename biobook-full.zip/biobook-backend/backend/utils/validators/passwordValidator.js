const passwordValidator = (password) => {
   const validRegex = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{6,}$/
   return validRegex.test(password);
}


module.exports = {
   passwordValidator
};