const schemaOptions = {
   toObject: {
      virtuals: true,
      versionKey: false,
   },
   toJSON: {
      virtuals: true,
      versionKey: false,
   }
}


module.exports = {
   schemaOptions
}