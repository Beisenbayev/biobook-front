const bcrypt = require('bcryptjs');

const generateEncryptedPassword = async (password) => {
   const solt = await bcrypt.genSalt(10);
   const hashedPassword = await bcrypt.hash(password, solt);

   return hashedPassword;
}

const comparePasswords = async (password, hashedPassword) => {
   const isMatch = await bcrypt.compare(password, hashedPassword);
   return isMatch;
};


module.exports = {
   generateEncryptedPassword,
   comparePasswords
};