const mongoose = require('mongoose')
const { schemaOptions } = require('../utils/configs/modelConfigs')

const requestSchema = mongoose.Schema(
	{
		title: {
			type: String,
			required: [true, 'is required'],
		},
		description: {
			type: String,
			required: [true, 'is required'],
		},
		created_at: {
			type: Date,
			default: Date.now,
		},
	},
	schemaOptions
)

module.exports = mongoose.model('Request', requestSchema)
