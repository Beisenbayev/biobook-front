import React from 'react';
import { BasePropertyProps } from 'adminjs';
import { Label, Box, DropZone, DropZoneProps } from '@adminjs/design-system'

interface Props { }

const UploadImage: React.FC<BasePropertyProps> = (props): JSX.Element => {
   const { property, onChange } = props

   const handleDropZoneChange: DropZoneProps['onChange'] = (files) => {
      onChange(property.name, files[0]);
   }

   return (
      <Box>
         <Label>{property.label}</Label>
         <DropZone onChange={handleDropZoneChange} />
      </Box>
   );
}


export default UploadImage;