const AdminJS = require('adminjs')

const Admin = require('../models/adminModel')
const User = require('../models/userModel')
const Termin = require('../models/terminModel')
const Card = require('../models/cardModel')
const Request = require('../models/requestModel')

const adminParent = {
	name: 'ADMINISTRATION',
	icon: 'Locked',
}

const terminParent = {
	name: 'TERMINS',
	icon: 'Grid',
}

const userParent = {
	name: 'USERS',
	icon: 'User',
}

const adminJs = new AdminJS({
	resources: [
		{
			resource: Admin,
			options: {
				parent: adminParent,
			},
		},
		{
			resource: User,
			options: {
				parent: userParent,
				listProperties: ['email', 'first_name', 'last_name', 'created_at'],
			},
		},
		{
			resource: Termin,
			options: {
				parent: terminParent,
			},
		},
		{
			resource: Card,
			options: {
				parent: terminParent,
			},
		},
		{
			resource: Request,
			options: {
				parent: terminParent,
			},
		},
	],
	rootPath: '/admin',
	loginPath: '/admin/login',
	branding: {
		companyName: 'Biobook | Admin Panel',
		softwareBrothers: false,
		favicon: '',
	},
})

module.exports = adminJs
