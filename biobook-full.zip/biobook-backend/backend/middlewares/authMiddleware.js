const jwt = require('jsonwebtoken')
const dotenv = require('dotenv').config
const asyncHandler = require('express-async-handler')
const User = require('../models/userModel')

const protect = asyncHandler(async (req, res, next) => {
	let token

	if (
		req.headers.authorization &&
		req.headers.authorization.startsWith('Bearer')
	) {
		try {
			//token from authorization (Bearer ***.***.***)
			token = req.headers.authorization.split(' ')[1]
			//decoded token
			const decodedToken = jwt.verify(token, process.env.JWT_TOKEN_SECRET)
			//find the user
			const user = await User.findById(decodedToken.id)

			if (user) {
				//put user data to request object
				req.user = user
			} else {
				//if there is no user in datebase with the given email
				req.user = null
				res.status(401)
				throw new Error('Invalid token')
			}

			next()
		} catch (error) {
			res.status(401)
			throw new Error('Invalid token')
		}
	}

	if (!token) {
		res.status(401)
		throw new Error('Not authorized')
	}
})

module.exports = {
	protect,
}
